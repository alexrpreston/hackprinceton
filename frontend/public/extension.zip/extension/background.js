chrome.runtime.onInstalled.addListener(function() {
  console.log('rightwithsway background.js: onInstalled');
});
